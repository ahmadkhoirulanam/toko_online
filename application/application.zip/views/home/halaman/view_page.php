<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'><?= $record['judul']; ?></li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="terms-conditions-page">
			<div class="row">
				<div class="col-lg-12 terms-conditions">
	<h2 class="heading-title"><?= $record['judul']; ?></h2>
	<div class="">
	
	
	
		  <?= $record['isi_halaman']; ?>
		  
		  
		  
	</div>
</div>			
</div><!-- /.row -->
</div><!-- /.sigin-in-->

<br/><br/>