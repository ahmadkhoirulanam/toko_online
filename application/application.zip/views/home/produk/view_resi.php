<div class="row">
  <div class="col-md-6 mx-auto">
    <h5>Cek Resi</h5>
    <p>Masukan no. resi pada pada form dibawah ini.</p>
    <form method="get" action="https://cekresi.com" target="_BLANK">
      <div class="input-group mb-3">
        <input type="text" name="noresi" value="" class="form-control" placeholder="Masukan no resi..." aria-label="Recipient's username" aria-describedby="basic-addon2">
        <div class="input-group-append">
          <button class="btn btn-black" type="submit">Cek resi</button>
        </div>
      </div>
    </form>


  </div>
</div>